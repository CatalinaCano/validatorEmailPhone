using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using System.Text;
using FxEmailPhoneSyntaxValidation.Class.Serialization;
using FxSyntaxEmailValidation.Class.Validation;
using FxEmailPhoneSyntaxValidation.Class.Validation;

namespace FxEmailPhoneSyntaxValidation
{
    public static class FxEmailPhoneSyntaxValidation
    {
        [FunctionName("fx_email_phone_syntax_validation")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req, ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            //Recibe el flujo de entrada
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

            //Deserealiza el request y obtiene los parametros de entrada
            InputData input = JsonConvert.DeserializeObject<InputData>(requestBody);

            if (input != null && (!String.IsNullOrWhiteSpace(input.Email) || !String.IsNullOrWhiteSpace(input.Phone)))
            {
                //Valida Email
                EmailResult emailResult = null;
                if (!String.IsNullOrWhiteSpace(input.Email))
                {
                    emailResult = new EmailResult(input.Email, EmailValidator.IsSyntaxValid(input.Email));
                }

                //Valida Celular
                PhoneResult phoneResult = null;
                if (!String.IsNullOrWhiteSpace(input.Phone))
                {
                    phoneResult = new PhoneResult(input.Phone, PhoneValidator.IsSyntaxValid(input.Phone));
                }

                //Retorna resultado de la validaci�n
                Result result = new Result(emailResult, phoneResult);
                return new HttpResponseMessage(statusCode: HttpStatusCode.OK)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(result), Encoding.UTF8, "application/json")
                };
            } else
            {
                return new HttpResponseMessage(statusCode: HttpStatusCode.BadRequest)
                {
                    Content = new StringContent("Please pass an email or phone in the request body", Encoding.UTF8, "application/json")
                };
            }
        }
    }
}
