﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace FxEmailPhoneSyntaxValidation.Class.Validation
{
    class PhoneValidator
    {
        public static bool IsSyntaxValid(string phone)
        {
            string pattern = @"^(573|3)[0-9]{9}$";
            Regex rgx = new Regex(pattern, RegexOptions.None);
            return rgx.IsMatch(phone);
        }
    }
}
