﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace FxEmailPhoneSyntaxValidation.Class.Serialization
{
    /*
    * Clase de serialización para el resultado de la validación del celular
    */
    class PhoneResult
    {

        public PhoneResult()
        {

        }

        public PhoneResult(string phone, bool isValid)
        {
            Phone = phone;
            this.isValid = isValid;
        }

        [JsonProperty("phone")]
        public string Phone { get; set; }
        [JsonProperty("isValid")]
        public bool isValid { get; set; }

    }
}
