﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace FxEmailPhoneSyntaxValidation.Class.Serialization
{
    /*
    * Clase de serialización para el resultado de la validación del correo
    */
    class EmailResult
    {

        public EmailResult()
        {

        }

        public EmailResult(string email, bool isValid)
        {
            Email = email;
            this.isValid = isValid;
        }

        [JsonProperty("email")]
        public string Email { get; set; }
        [JsonProperty("isValid")]
        public bool isValid { get; set; }

    }
}
