﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace FxEmailPhoneSyntaxValidation.Class.Serialization
{
    /*
    * Clase de serialización para la respuesta de la función
    */
    class Result
    {
        
        public Result()
        {

        }
        
        public Result(EmailResult emailResult, PhoneResult phoneResult)
        {
            EmailResult = emailResult;
            PhoneResult = phoneResult;
        }

        [JsonProperty("emailResult", NullValueHandling = NullValueHandling.Ignore)]
        public EmailResult EmailResult { get; set; }
        [JsonProperty("phoneResult", NullValueHandling = NullValueHandling.Ignore)]
        public PhoneResult PhoneResult { get; set; }

    }
}
