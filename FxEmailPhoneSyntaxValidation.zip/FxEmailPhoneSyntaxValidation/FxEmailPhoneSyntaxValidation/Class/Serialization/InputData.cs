﻿using Newtonsoft.Json;

namespace FxEmailPhoneSyntaxValidation.Class.Serialization
{
    /*
    * Clase de serialización para los parametros de entrada
    */
    class InputData
    {

        [JsonProperty("email")]
        public string Email { get; set; }
        [JsonProperty("phone")]
        public string Phone { get; set; }

    }
}
